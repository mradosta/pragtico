<?php
	class UnixImplementedAction extends AppModel {
		public $useTable = 'unix_implemented_actions';
	}