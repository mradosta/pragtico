<?php
	class UnixAction extends AppModel {
			public $useTable = 'unix_actions';
	}