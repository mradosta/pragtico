<?php	
	class UnixPrivilege extends AppModel {
		public $useTable = 'unix_privileges';
		
	}